package com.example.productservice.datalayer;

public enum ProductMethod {
    IN_STORE,
    ONLINE
}
