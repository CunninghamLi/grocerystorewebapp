INSERT INTO product (product_id, name, description, price, stock_quantity) VALUES
                                                                               ('p001', 'Organic Apples', 'Fresh organic apples (1kg)', 3.99, 50),
                                                                               ('p002', 'Whole Milk', '1L full cream milk', 2.49, 75),
                                                                               ('p003', 'Brown Bread', 'Whole grain brown bread loaf', 1.99, 40),
                                                                               ('p004', 'Free-Range Eggs', 'Pack of 12 free-range eggs', 4.50, 60),
                                                                               ('p005', 'Almond Butter', 'Smooth almond butter (250g)', 6.99, 30);