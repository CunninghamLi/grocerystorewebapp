rootProject.name = "payment-service"
