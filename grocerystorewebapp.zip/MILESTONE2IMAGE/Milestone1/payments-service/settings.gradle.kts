rootProject.name = "payments-service"
