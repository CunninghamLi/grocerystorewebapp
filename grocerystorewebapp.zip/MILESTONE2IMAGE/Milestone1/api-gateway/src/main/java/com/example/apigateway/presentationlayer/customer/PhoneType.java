// src/main/java/com/example/apigateway/presentationlayer/customer/PhoneType.java
package com.example.apigateway.presentationlayer.customer;

public enum PhoneType {
    HOME, MOBILE, WORK
}
