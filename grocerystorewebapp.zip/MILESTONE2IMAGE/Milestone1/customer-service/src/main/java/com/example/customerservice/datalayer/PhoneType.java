package com.example.customerservice.datalayer;

public enum PhoneType {
    HOME,
    WORK,
    MOBILE
}