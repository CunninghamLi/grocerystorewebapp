


INSERT INTO customers (id, first_name, last_name, email_address, street_address, city, province, country, postal_code) VALUES
                                                                                                                       (1, 'Alice', 'Smith', 'alice.smith@example.com', '1234 Road St', 'Townsville', 'State', 'Country', '12345'),
                                                                                                                       (2, 'Bob', 'Brown', 'bob.brown@example.com', '2345 Lake Ave', 'Lakeside', 'Province', 'Country', '23456'),
                                                                                                                       (3, 'Charlie', 'Davis', 'charlie.davis@example.com', '3456 Forest Blvd', 'Forestville', 'Province', 'Country', '34567'),
                                                                                                                       (4, 'Diana', 'Evans', 'diana.evans@example.com', '4567 Mountain Path', 'Mountainview', 'Province', 'Country', '45678'),
                                                                                                                       (5, 'Edward', 'Foster', 'edward.foster@example.com', '5678 River Road', 'Riverton', 'Province', 'Country', '56789'),
                                                                                                                       (6, 'Fiona', 'Garcia', 'fiona.garcia@example.com', '6789 Ocean Dr', 'Oceanview', 'Province', 'Country', '67890'),
                                                                                                                       (7, 'George', 'Hill', 'george.hill@example.com', '7890 Valley Cir', 'Valleytown', 'Province', 'Country', '78901'),
                                                                                                                       (8, 'Hannah', 'Irwin', 'hannah.irwin@example.com', '8901 Plain Field', 'Plainville', 'Province', 'Country', '89012'),
                                                                                                                       (9, 'Ian', 'Johnson', 'ian.johnson@example.com', '9012 Spring St', 'Springfield', 'Province', 'Country', '90123'),
                                                                                                                       (10, 'Julia', 'Klein', 'julia.klein@example.com', '0123 Winter Rd', 'Winterville', 'Province', 'Country', '01234');



