package com.example.orderservice.datalayer;

public enum PhoneType {
    MOBILE,
    HOME,
    WORK
}
